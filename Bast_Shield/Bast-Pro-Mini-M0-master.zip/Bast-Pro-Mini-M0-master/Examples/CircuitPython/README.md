##Ejemplos de codigo en CircuitPython

###Todos los ejemplos estan optimizados para la tarjeta:

##Bast Pro Mini M0.

+ blink.py
>Enciende y apaga el Led incroporado en la tarjeta.
+ i2c_show.py
> Muestra todos los pines que pueden ser usados para i2c
+ pinout_show.py
>Muestra los pines disponibles en la tarjeta.
+ uart_show.py
>Muestra todos los pines que pueden ser usados para UART.
