#Muestra el PinOut de la Tarjeta
import  board

print(dir(board))

