
Escornabot 3D Model
===================

Further info at http://escornabot.com/web/content/how


## Current version

  * [Brivoi edition](Brivoi/README.md) (May 2015)
  

## Old versions

  * [Placidus edition](Placidus/README.md) (November 2014)


