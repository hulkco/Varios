* Transfer "IdleHandsDev" folder into your Arduino/hardware folder to view the "HCC Module" board. Otherwise use either "Arduino Zero (Native USB)" or "Sparkfun SAMD Breakout Board" *
