# SAMD21 Bridge Module
An easy to solder Arduino compatible surface mount module aimed to bridge the gap between using "off the shelf" microcontrollers to creating custom PCBs. 
