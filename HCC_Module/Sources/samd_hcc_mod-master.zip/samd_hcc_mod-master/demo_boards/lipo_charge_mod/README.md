# Sensory_Adaptation_Bot
A Neural network robot for learning new sensors without programming them specifically. 
