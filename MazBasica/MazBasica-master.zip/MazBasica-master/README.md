# MazBasica v1.0
Arduino UNO trainer shield.
Source code as included in Ardublock, which is a visual programming language, which will enable students ages 8 and up, marvelous introduction to the world of programming and physical computing.
/////
Tarjeta entrenadora para Arduino UNO.
Se incluye código fuente en Ardublock, el cual es un lenguaje de programacion visual, el cual permitira a los alumnos de 8 años en adelante, introducirse al maravillos mundo de la programacion y la computacion fisica.
