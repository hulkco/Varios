# micro-bit-eagle-libraries
Eagle libraries for the microbit edge connectors
