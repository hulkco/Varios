### Badge Schedule

- [X] Solder and test boring square board by ~~JAN 5~~ JAN 1
- [X] Revise into final design and order by ~~JAN 7~~ JAN 3
- [X] Order less boring less square final design on ~~JAN 7~~ JAN 3
- [X] Receive rev2 design by ~~JAN 15~~ JAN 7
- [ ] Test rev2 design by JAN 15
- [ ] Revise & finalize design by JAN 17
- [ ] Order PCBA from TBD by JAN 18 (Macrofab or China [New year is Jan 25])
- [ ] Receive PCBA (4 weeks) around FEB 15 (3 weeks of slack)
- [ ] Bsides SD is MAR 7/8
