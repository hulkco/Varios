# Taller-iniciacion-micro-bit
Documentació en format de fitxes per poder realitzar una petita introducció a la programació de la micro:bit
