#New footprints for new @arduino  Nano 33 in @kicad_pcb

![](images/003.png) 
![](images/001.png) 
![](images/002.png) 

